#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <X11/Xlib.h>
#include <pthread.h>
#include <jni.h>
#include <time.h>
#include "clavicom_gui_engine_click_ClickEngine.h"

//variables JNI
JNIEnv *environement = NULL;
jobject object = NULL;
jclass cls;
jmethodID mid;

//variables thread
pthread_t mouseThread;
int *codeRetour;

//variables communication
unsigned long event_mask;
bool end = false;
bool actu = false;
bool inhibit = false ;

/*
TYPE de click a regarder a declarer ICI
*/


/*
FONCTION mouseHookStart
Un thread dans lequel, on demande a X11 de regarder si il y a des appels souris, afin de les traiter.
*/
void *mouseCall( void* param){
   //Declaration des variables
  int screen_num;
	unsigned long background, border;
	Window win;
	XEvent ev;
	Display *dpy;

	/* First connect to the display server, as specified in the DISPLAY 
	environment variable. */
	dpy = XOpenDisplay(NULL);
	if (!dpy) {fprintf(stderr, "unable to connect to display");}

	/* these are macros that pull useful data out of the display object */
	/* we use these bits of info enough to want them in their own variables */
	screen_num = DefaultScreen(dpy);
	background = BlackPixel(dpy, screen_num);
	border = WhitePixel(dpy, screen_num);

	win = XCreateWindow(dpy, DefaultRootWindow(dpy),
            0, 0, 400, 400, 0, CopyFromParent, CopyFromParent,
            CopyFromParent, 0, 0);

	/* tell the display server what kind of events we would like to see */
	XSelectInput(dpy, win, ButtonPressMask);

	/* okay, put the window on the screen, please */
	XMapWindow(dpy, win);
   XFlush(dpy);
	/* as each event that we asked about occurs, we respond.  In this
	 * case we note if the window's shape changed, and exit if a button
	 * is pressed inside the window */
  
   while(1)
   {
      XNextEvent(dpy, &ev);
      if(ev.type == ButtonPress){
         if(ev.xbutton.button == Button1){
            actu = true;
         }
         
      }
   }
   
   /*
   FERMETURE DES FICHIERS, THREADS ET DISPLAY   
   */
  
   XCloseDisplay(dpy);
   int code =1;
   pthread_exit(&code);
}

/*
A MODIFIER CAR POUR WINDOWS
DOIT INITIALISER LE THREAD QUI S'OCCUPE DES INTERRUPTIONS SOURIS
*/
JNIEXPORT void JNICALL Java_clavicom_gui_engine_click_ClickEngine_InitMouseHook(JNIEnv* env, jobject obj, jint typeClick)
{
	environement = env;
	object = obj;
	event_mask = 0;
	/*	
	switch( typeClick )
	{
	ICI REMPLACER PAR LES VALEURS X11 CORRESPONDANTES

		case 0:
			event_mask = event_mask|;
			break;
		case 1:
			event_mask = WM_LBUTTONDOWN;
			break;
		case 2:
			event_mask = WM_RBUTTONDOWN;
			break;
		case 3:
			event_mask = WM_RBUTTONUP;
			break;
		default:
			event_mask = WM_LBUTTONUP;
			break;
	}
   */	

	/*
	CREER THREAD APPELANT LA FONCTION S'OCCUPANT DES INTERRUPTIONS SOURIS	
	*/
	int ret;
	ret = pthread_create( &mouseThread, NULL, mouseCall, NULL);
   if(ret!=0){
   perror("pthread_create");
   exit(EXIT_FAILURE);
   }
	while(!end){
	   if(actu){
	      actu = false;
	       cls = (*environement)->GetObjectClass(environement, object) ;
//          Recuperation de la methode a appeler
			   mid = (*environement)->GetMethodID(environement,cls,"Callback","()V");
//          appel de la fonction CallBack en JAVA
			   (*environement)->CallVoidMethod(environement,object, mid);
	   }
	}
}


/*
FONCTION POUR TERMINER LE THREAD VIA JNI
*/
JNIEXPORT void JNICALL Java_clavicom_gui_engine_click_ClickEngine_FinishMouseHook(JNIEnv *env, jobject obj)
{
    end = true;   
 if(pthread_join( mouseThread, (void**) &codeRetour) !=0){ 
      perror("join");
      exit(EXIT_FAILURE);
    }
}

/*
FONCTION POUR INHIBER OU NON LE MOUSEHOOK : LA MEME QUE POUR WINDOWS
*/
JNIEXPORT void JNICALL Java_clavicom_gui_engine_click_ClickEngine_InhibitMouseHook(JNIEnv *env, jobject obj, jboolean myInhibit)
{
	inhibit = myInhibit;
}
//MAIN PR DEBUG
/*
int main(void){

   int ret;
	ret = pthread_create( &mouseThread, NULL, mouseCall, NULL);
   if(ret!=0){
   perror("pthread_create");
   exit(EXIT_FAILURE);
   }
   end = false;
   printf("thread cree\n");
   while(1){
      if(actu){
         printf("testconcluant\n");
   actu =false;
   }
    if(pthread_join( mouseThread, (void**) &codeRetour) !=0){ 
         perror("join");
         exit(EXIT_FAILURE);
       }
   }
   return 0;
}*/
