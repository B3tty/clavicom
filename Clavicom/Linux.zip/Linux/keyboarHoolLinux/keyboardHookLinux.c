#include <stdlib.h>
#include <stdbool.h>
#include <math.h>
#include <X11/Xlib.h>
#include <time.h>
#include <pthread.h>
#include <jni.h>
#include <time.h>
#include "clavicom_core_engine_CPreditionEngine_KeyboardHook.h"
//#define _BSD_SOURCE // For usleep() and getdtablesize()

//VARIABLES GLOBALES A PARTAGER ENTRE LE THREAD ET LA FONCTINO JNI
int keysym;
bool end = false;
bool actu = false;

void *keylogCall( void* param){
    FILE *file = stdout;
    int code;
    char keys_current[32], keys_last[32];
    int i, keycode;
    char *key;
    // Open X display
    Display *display = XOpenDisplay(NULL);
    if (!display) {
        fprintf(stderr, "Error: Could not open X display\n");
        exit(EXIT_FAILURE);
    }
 
    // Open output file
        file = fopen("debugKeyboard.txt","a");
        if (!file) {
            perror("echec");
            exit(EXIT_FAILURE);
        }
  
   XQueryKeymap(display, keys_last);

  //boucle de traitement keylogger
  while (!end) {
        fflush(file);
        XQueryKeymap(display, keys_current);
         keysym = 0;
        /*
        FONCTIONNEMENT GENERAL :
        keycode recoit un emplacement de touche (x,y), qui est convertit en ASCII dans keysym. key est la pour le debug, pour convertir directement    
        
        
        */
        for (i = 0; i < 32; i++) {
            if (keys_current[i] != keys_last[i] ) {
                keycode = i * 8 + (int)log2((unsigned)(keys_current[i] ^ keys_last[i]));
                /* TRAITEMENT / CONVESION EN ASCII
                les touches 's' 'v' 'i' 'o' car elles sont mal interpretees par la fonction XKeycodeToKeysym */
                //traitement m
                if(keycode == 71)
                  keysym = 109;
                //traitement s
                else if (keycode == 63)
                  keysym = 115;
                //traitement v
                else if (keycode == 79)
                  keysym = 118;
                //traitement i
                else if (keycode == 55)
                  keysym = 105;
                //traitement tab
                else if ( keycode == 47 )
                  {keysym = 2; actu = true;}
                //sinon, on laisse le code comme il est
                else
                  keysym = XKeycodeToKeysym(display, keycode, 0);
                
                
                
                /* TRAITEMENT TOUCHE */
                
               
                  /* DEBUG */
                key = XKeysymToString(keysym);
                //si l'action detectee est un appui de touche
                //(un bit a 1 correspond a un appui sur une touche)
                
                 if( (96 < keysym)  && ( keysym < 123) ){
                //pas de traitement a faire, keysym correspond deja a l'ASCII de la lettre
                //actualisation pour envoyer au JNI
                 actu = true;
                 
                //traitement du caractere rentre
                }   
                 
                
                //touches respectivement BackSpace et Suppr
                else if ( (keysym == 65288) || (keysym == 269025133) ){
                 //conversion en donnee exploitable pour le callback
                 keysym = 1;
                 //actualisation pour envoyer au JNI
                 actu = true;
                }
                //touches respectivement Space, Return, TAB End, Home, Escape, Left, Right, Up, Down, NextPage, Prior (previous page)
                else if( (keycode == 65)  ||   //space
                    (keycode == 36)  ||   //return
                    (keycode == 115) ||   //end
                    (keycode == 110) ||   //home
                    (keycode == 9)   ||   //escape
                    (keycode == 113) ||   //left
                    (keycode == 114) ||   //right
                    (keycode == 135) ||   //up
                    (keycode == 116) ||   //down             
                    (keycode == 117) ||   //next
                    (keycode == 112)      //prior
                   ){
                  //conversion en donnee exploitable pour le callback
                  keysym = 2;
                  //actualisation pour envoyer au JNI
                  actu = true;
                }
                else{
                  fprintf(file,"erreur\n");
                  keysym = 0;
                  //actualisation pour envoyer au JNI
                  actu = true;
                }
              
                                
            }
            
            
            //on raffraichi la configuration du clavier actuel (appui ou non des touches)
            keys_last[i] = keys_current[i];
        }
      //on attend 1ms pour eviter de trop consommer pour le processeur
      usleep(1000);
    }
    XCloseDisplay(display);
    fclose(file);
    //terminaison du thread
    code =1;
    pthread_exit(&code);

}

/*  JNI*/
JNIEXPORT void JNICALL Java_clavicom_core_engine_CPredictionEngine_getKeyLog(JNIEnv *env, jobject obj){

   //declarations
   jclass cls;
   jmethodID mid;
   pthread_t keyThread;
   int *codeRetour;
   int ret;


   ret = pthread_create( &keyThread, NULL, keylogCall, NULL);
   if(ret!=0){
   perror("pthread_create");
   exit(EXIT_FAILURE);
   }

   //pooling pour l'envoi JNI
   while(!end){
      if(actu){
         //actualisation du boolean
         actu = false;
         //envoi de la donnee en JNI

			cls = (*env)->GetObjectClass(env, obj) ;
			//Recuperation de la methode a appeler
			mid = (*env)->GetMethodID(env,cls,"CallbackC","(I)V");
			//environnement->CallVoidMethodID(cls,"CallBack","(I)V");
			//appel de la fonction CallBack en JAVA
			(*env)->CallVoidMethod(env,obj, mid, keysym);

      }
//      usleep(1000);
   }
    
   //attente de terminaison du thread
    if(pthread_join( keyThread, (void**) &codeRetour) !=0){ 
      perror("join");
      exit(EXIT_FAILURE);
    }

}
